# 🚀 Lead Auto-Assignment System (Salesforce)

Automatically assigns incoming **Leads** to different Salesforce users based on the Lead's `Rating` field (e.g., Hot, Warm, Cold). This project uses **Apex Triggers**, **Custom Metadata**, and a **custom logging object** to ensure flexibility and traceability.

## 🧩 Features

- 🔄 Auto-assigns Lead records based on their Rating
- 🧠 Logic controlled via **Custom Metadata** (no hardcoding!)
- 📝 Tracks all assignments in a custom log object
- 💯 Includes test class for 100% code coverage

## 🧱 Components

| Type                | Name                       | Description                             |
|---------------------|----------------------------|-----------------------------------------|
| Trigger             | `LeadAssignmentTrigger`     | Runs on Lead insert                     |
| Apex Class          | `LeadAssignmentHandler`     | Handles assignment logic and logging    |
| Apex Test Class     | `LeadAssignmentHandlerTest` | Unit tests for trigger and logic        |
| Custom Metadata     | `Lead_Assignment__mdt`      | Maps Rating to User                     |
| Custom Object       | `Lead_Assignment_Log__c`    | Logs each assignment made               |

## 🛠️ Setup Instructions

1. **Create Custom Metadata Type**
2. **Create Custom Object**
3. **Deploy Apex Code**

## 📂 Repository Structure

```
lead-auto-assignment/
├── LeadAssignmentHandler.cls
├── LeadAssignmentTrigger.trigger
├── LeadAssignmentHandlerTest.cls
└── README.md
```

## 🧑‍🎓 Author

**Vijay Shivappa Banakar**  
Trailblazer Profile: [https://www.salesforce.com/trailblazer/vbanakar](https://www.salesforce.com/trailblazer/vbanakar)